﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("Task-Modal Dialogs With Special Handling")]
[assembly: AssemblyDescription("Sample code for the 'Task-Modal Headaches' blog post (www.thehumbleprogrammer.com/task-modal-headaches).")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("The Humble Programmer")]
[assembly: AssemblyProduct("Task-modal dialogs sample code.")]
[assembly: AssemblyCopyright("Copyright ©  2012 Igor Roncevic")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: ThemeInfo(
    ResourceDictionaryLocation.None,
    ResourceDictionaryLocation.SourceAssembly
)]

[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
